<!--  -->
<template>
  <div>
      <p class="header">神雕侠侣2新闻后台管理</p>
  </div>
</template>

<script>
export default {
  data () {
    return {
    }
  }
}

</script>
<style lang='less' scoped>
.header {
    width: 100%;
    height: 10vh;
    line-height: 10vh;
    text-align: center;
    font-size: 30px;
    font-weight: 700;
    color: #ffd04b;
    background-color: #545c64;
}
</style>
